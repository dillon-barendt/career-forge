import { Worker } from "@notionhq/workers";

const worker = new Worker();

export default worker;

type JsonRecord = Record<string, unknown>;

function nowIso(): string {
  return new Date().toISOString();
}

function result(kind: string, payload: JsonRecord): string {
  return JSON.stringify(
    {
      kind,
      generatedAt: nowIso(),
      ...payload,
    },
    null,
    2,
  );
}

worker.tool("intakeOpportunity", {
  title: "Opportunity Intake Worker",
  description:
    "Normalize a job opportunity from a source URL or manually supplied fields and return a Notion mutation plan.",
  schema: {
    type: "object",
    properties: {
      source: {
        type: "string",
        description: "Source system such as Greenhouse, Lever, Ashby, Workday, LinkedIn, Indeed, or manual.",
      },
      url: {
        type: "string",
        description: "Original job posting or application URL.",
      },
      title: {
        type: "string",
        description: "Role title when already known.",
      },
      company: {
        type: "string",
        description: "Company name when already known.",
      },
      location: {
        type: "string",
        description: "Location or remote policy text, if available.",
      },
      salary: {
        type: "string",
        description: "Compensation range or text, if available.",
      },
    },
    required: ["source", "url"],
    additionalProperties: false,
  },
  execute: ({ source, url, title, company, location, salary }) =>
    result("opportunity_intake_plan", {
      normalizedOpportunity: {
        source,
        sourceUrl: url,
        title: title ?? "Unknown role title",
        company: company ?? "Unknown company",
        location: location ?? "Unknown location",
        salary: salary ?? "Unknown compensation",
        status: "Needs Review",
        dedupeKey: `${String(source).toLowerCase()}:${String(url).toLowerCase()}`,
      },
      proposedNotionWrites: [
        "Create or update Company record",
        "Create or update Opportunity record",
        "Attach Application Source metadata",
        "Create Manual Review task if required fields are missing",
      ],
      humanReviewRequired: !title || !company,
      nextAction: "Verify extracted fields, then persist through the Career Ops Notion provider.",
    }),
});

worker.tool("classifyRecruiterEmail", {
  title: "Gmail Recruiter Worker",
  description:
    "Classify a recruiter or application email snippet and return a Notion write plan for the career pipeline.",
  schema: {
    type: "object",
    properties: {
      from: {
        type: "string",
        description: "Sender email or display name.",
      },
      subject: {
        type: "string",
        description: "Email subject.",
      },
      snippet: {
        type: "string",
        description: "Email snippet or body excerpt.",
      },
      threadId: {
        type: "string",
        description: "Gmail thread identifier, when available.",
      },
    },
    required: ["from", "subject", "snippet"],
    additionalProperties: false,
  },
  execute: ({ from, subject, snippet, threadId }) => {
    const haystack = `${subject} ${snippet}`.toLowerCase();
    const category = haystack.includes("interview")
      ? "Interview Scheduling"
      : haystack.includes("unfortunately") || haystack.includes("not moving forward")
        ? "Rejection"
        : haystack.includes("apply") || haystack.includes("application")
          ? "Application Update"
          : "Recruiter / Needs Review";

    return result("gmail_recruiter_classification", {
      message: { from, subject, snippet, threadId: threadId ?? null },
      classification: {
        category,
        confidence: category === "Recruiter / Needs Review" ? 0.55 : 0.75,
        humanReviewRequired: true,
      },
      proposedNotionWrites: [
        "Create or update Email Thread record",
        "Create or update Recruiter Contact record",
        "Link message to Opportunity if match is unambiguous",
        "Create Follow-Up or Manual Review task",
      ],
      nextAction: "Review classification before mutating application status or sending a reply.",
    });
  },
});

worker.tool("planInterviewScheduling", {
  title: "Interview Scheduling Worker",
  description:
    "Extract interview scheduling intent and produce a Calendar/Notion coordination plan.",
  schema: {
    type: "object",
    properties: {
      company: {
        type: "string",
        description: "Company name.",
      },
      role: {
        type: "string",
        description: "Role title.",
      },
      emailSnippet: {
        type: "string",
        description: "Scheduling email excerpt.",
      },
      proposedTime: {
        type: "string",
        description: "Candidate interview time if already parsed.",
      },
      meetingUrl: {
        type: "string",
        description: "Meeting URL if present.",
      },
    },
    required: ["company", "role", "emailSnippet"],
    additionalProperties: false,
  },
  execute: ({ company, role, emailSnippet, proposedTime, meetingUrl }) =>
    result("interview_scheduling_plan", {
      interview: {
        company,
        role,
        stage: "Needs Scheduling Review",
        proposedTime: proposedTime ?? null,
        meetingUrl: meetingUrl ?? null,
        sourceExcerpt: emailSnippet,
      },
      proposedNotionWrites: [
        "Create or update Interview record",
        "Create Interview Prep task",
        "Link interview to Opportunity timeline",
        "Queue Calendar event creation if the time is confirmed",
      ],
      calendarSideEffectAllowed: Boolean(proposedTime),
      humanReviewRequired: true,
      nextAction: proposedTime
        ? "Confirm parsed time before creating or updating Google Calendar."
        : "Ask for or extract concrete interview time before creating Calendar event.",
    }),
});

worker.tool("reviewPipelineHealth", {
  title: "Application Status Guardian Worker",
  description:
    "Generate a health-review plan for stale opportunities, follow-ups, and status conflicts.",
  schema: {
    type: "object",
    properties: {
      staleDays: {
        type: "number",
        description: "Number of inactive days after which an opportunity should be reviewed.",
      },
      includeFollowUps: {
        type: "boolean",
        description: "Whether to create follow-up recommendations.",
      },
      includeStatusConflicts: {
        type: "boolean",
        description: "Whether to look for Gmail/Calendar/Notion status conflicts.",
      },
    },
    required: ["staleDays"],
    additionalProperties: false,
  },
  execute: ({ staleDays, includeFollowUps, includeStatusConflicts }) =>
    result("pipeline_health_review_plan", {
      rules: [
        `Flag active opportunities with no activity in ${staleDays} days`,
        includeFollowUps ? "Create follow-up tasks for stale applications" : "Do not create follow-up tasks",
        includeStatusConflicts ?? true
          ? "Detect conflicts between Gmail, Calendar, and Notion statuses"
          : "Skip status conflict detection",
      ],
      proposedNotionWrites: [
        "Create Pipeline Health summary",
        "Create Manual Review tasks for ambiguous transitions",
        "Append Automation Audit Log entries",
      ],
      forbiddenAutomaticActions: [
        "Do not silently mark opportunities rejected",
        "Do not permanently delete career data",
        "Do not send emails without explicit approval",
      ],
      humanReviewRequired: true,
      nextAction: "Run against current Notion pipeline data through the provider layer, then review generated mutations.",
    }),
});

worker.tool("generateCareerIntelligence", {
  title: "Career Intelligence Worker",
  description:
    "Create a company/role intelligence brief with fit notes, interview talking points, and portfolio positioning.",
  schema: {
    type: "object",
    properties: {
      company: {
        type: "string",
        description: "Company name.",
      },
      role: {
        type: "string",
        description: "Role title.",
      },
      opportunityUrl: {
        type: "string",
        description: "Opportunity URL, if available.",
      },
      companySummary: {
        type: "string",
        description: "Known company summary or research notes.",
      },
      roleSummary: {
        type: "string",
        description: "Known role summary or job description notes.",
      },
    },
    required: ["company", "role"],
    additionalProperties: false,
  },
  execute: ({ company, role, opportunityUrl, companySummary, roleSummary }) =>
    result("career_intelligence_brief", {
      target: { company, role, opportunityUrl: opportunityUrl ?? null },
      brief: {
        companySummary: companySummary ?? "Research required before using externally.",
        roleSummary: roleSummary ?? "Role details required before tailoring outreach.",
        likelyFitAngles: [
          "Platform and automation engineering",
          "AI-native workflow orchestration",
          "Marketplace/ticketing domain depth where relevant",
          "Provider abstractions and operational tooling",
        ],
        talkingPoints: [
          "Experience building event-driven systems and provider integrations",
          "Ability to convert manual workflows into auditable automation",
          "Strong alignment with typed Python, FastAPI, Pydantic, and agentic tooling",
        ],
      },
      proposedNotionWrites: [
        "Create or update Company Intelligence record",
        "Create Role Fit Notes",
        "Create Interview Talking Points",
        "Link relevant portfolio projects to the Opportunity",
      ],
      humanReviewRequired: true,
      nextAction: "Add source-backed research before using claims in outreach or interviews.",
    }),
});
