# Career Ops Notion Workers

This project contains the first real Notion Workers for the Career Forge / Career Ops workspace.

It exports one Notion Worker with five agent tools:

1. `intakeOpportunity` — Opportunity Intake Worker
2. `classifyRecruiterEmail` — Gmail Recruiter Worker
3. `planInterviewScheduling` — Interview Scheduling Worker
4. `reviewPipelineHealth` — Application Status Guardian Worker
5. `generateCareerIntelligence` — Career Intelligence Worker

## Prerequisites

The Notion Workers quickstart requires:

- Node.js 22+
- npm 10+
- Notion CLI installed with:

```bash
curl -fsSL https://ntn.dev | bash
```

## Install

```bash
cd career-ops-notion-workers
npm install
npm run typecheck
```

## Deploy

```bash
ntn workers deploy
```

Follow the CLI prompts to authenticate with the target Notion workspace.

## Test tools

```bash
ntn workers exec intakeOpportunity -d '{"source":"manual","url":"https://example.com/job","title":"Senior Software Engineer","company":"Example Co"}'

ntn workers exec classifyRecruiterEmail -d '{"from":"recruiter@example.com","subject":"Interview request","snippet":"Are you available this week?"}'

ntn workers exec planInterviewScheduling -d '{"company":"Example Co","role":"Senior Software Engineer","emailSnippet":"Can you meet Thursday at 2pm?"}'

ntn workers exec reviewPipelineHealth -d '{"staleDays":7,"includeFollowUps":true}'

ntn workers exec generateCareerIntelligence -d '{"company":"Example Co","role":"Senior Software Engineer","opportunityUrl":"https://example.com/job"}'
```

## Architecture stance

These Workers intentionally return structured mutation plans instead of directly writing to Notion or sending emails.

That preserves the Career Ops architecture rule:

- agents classify, enrich, and recommend
- providers own external system access
- Notion remains the persistence layer
- side effects remain explicit, idempotent, and auditable

